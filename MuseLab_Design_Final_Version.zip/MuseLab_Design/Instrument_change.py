from Functions import *
from mido import Message, MidiFile, MidiTrack, MetaMessage


def Instrument_change(file_path, instrument_list, Lock):
    """

    :param Lock: Check if the track number is locked
    :param file_path:
    :param instrument_list:
    :return:
    """
    print("------------------------------Getting Input_Midi_Information-----------------------------------")
    mid = MidiFile(file_path)
    Tempo = get_tempo(file_path)
    note_list = get_midi_info(file_path, 'note')
    velocity_list = get_midi_info(file_path, 'velocity')
    time_list = get_midi_info(file_path, 'time')
    for i in range(len(note_list)):
        print(note_list[i])
    print("note_length:", len(note_list))
    print("note_list:", note_list)
    print("time_length:", len(time_list))
    print("time:", time_list)
    print("velocity_length:", len(velocity_list))
    print("velocity_list:", velocity_list)
    print("Input_mid_Info: ", mid)
    print("MIDI data: ", mid)
    print("Melody_Tempo:", Tempo)
    print("---------------------------Done of Getting Input_Midi_Information------------------------------\n")

    New_mid = MidiFile()
    if Lock == 1:
        print("------------Creating a New Midi File According With Lock Track------------\n")
        Tracks = []
        ins_num = get_txt_info('num')
        print("All the represent number of different instrument: \n", ins_num)
        print("User Choice:\n", instrument_list)
        if type(instrument_list[-1]) == int:
            for i in range(len(instrument_list)-2):
                Tracks.append(MidiTrack())

            print("\n------Change instrument and tempo-----\n")
            for i in range(len(instrument_list)):
                if i > 1:
                    New_mid.tracks.append(Tracks[i-2])
                    Tracks[i-2].append(
                        Message('program_change', channel=0, program=ins_num[instrument_list[i-1][0] - 1], time=0))
                    Tracks[i-2].append(MetaMessage('set_tempo', tempo=bpm2tempo(instrument_list[-1]), time=0))
                    for j in range(len(note_list[i-2])):
                        Tracks[i-2].append(
                            Message('note_on', note=note_list[i-2][j], velocity=velocity_list[i-2][j],
                                    time=time_list[i-2][j]))
                    print("\nMelody instrument num: ", ins_num[instrument_list[i-1][0] - 1])

        else:
            for i in range(len(instrument_list)-1):
                Tracks.append(MidiTrack())
            print(Tracks)
            print("\n------Change instrument without changing tempo-----\n")
            for i in range(len(instrument_list)):
                if i > 0:
                    New_mid.tracks.append(Tracks[i - 1])
                    Tracks[i - 1].append(
                        Message('program_change', channel=0, program=ins_num[instrument_list[i][0] - 1], time=0))
                    Tracks[i - 1].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
                    for j in range(len(note_list[i-1])):
                        Tracks[i - 1].append(
                            Message('note_on', note=note_list[i - 1][j], velocity=velocity_list[i - 1][j],
                                    time=time_list[i - 1][j]))
                    print("\nMelody instrument num: ", ins_num[instrument_list[i][0] - 1])
                print("Tracks:", i-1, Tracks[i-1])
    elif Lock == 0:
        print("------------Creating a New Midi File According With Unlock Track------------\n")
        Tracks_num, Tracks = [], []
        if type(instrument_list[-1]) == int:
            for i in range(len(instrument_list)-1):
                if i > 0:
                    Tracks_num.append(len(instrument_list[i]))
                    Tracks.append([])
        else:
            for i in range(len(instrument_list)):
                if i > 0:
                    Tracks_num.append(len(instrument_list[i]))
                    Tracks.append([])
        print("Tracks_num:", Tracks_num)
        print("Tracks:", Tracks)
        for i in range(len(Tracks)):
            for j in range(Tracks_num[i]):
                Tracks[i].append(MidiTrack())
            print("Tracks ", i, len(Tracks[i]))
        print("Final Tracks:", Tracks)
        ins_num = get_txt_info('num')
        print("All the represent number of different instrument: \n", ins_num)
        print("User Choice:\n", instrument_list)
        if type(instrument_list[-1]) == int:
            print("\n------Change instrument and tempo-----\n")
            for i in range(len(instrument_list)):
                if i > 1:
                    for k in range(len(Tracks[i-2])):
                        New_mid.tracks.append(Tracks[i-2][k])
                        Tracks[i-2][k].append(
                            Message('program_change', channel=0, program=ins_num[instrument_list[i - 1][k] - 1], time=0))
                        Tracks[i-2][k].append(MetaMessage('set_tempo', tempo=bpm2tempo(instrument_list[-1]), time=0))
                        for j in range(len(note_list[i - 2])):
                            Tracks[i - 2][k].append(
                                Message('note_on', note=note_list[i - 2][j], velocity=velocity_list[i - 2][j],
                                        time=time_list[i - 2][j]))
                        print("\nMelody instrument num: ", ins_num[instrument_list[i - 1][k] - 1])

        else:
            for i in range(len(instrument_list) - 1):
                Tracks.append(MidiTrack())
            print(Tracks)
            print("\n------Change instrument without changing tempo-----\n")
            for i in range(len(instrument_list)):
                if i > 0:
                    for k in range(len(Tracks[i-1])):
                        New_mid.tracks.append(Tracks[i-1][k])
                        Tracks[i-1][k].append(
                            Message('program_change', channel=0, program=ins_num[instrument_list[i][k] - 1], time=0))
                        Tracks[i-1][k].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
                        for j in range(len(note_list[i - 1])):
                            Tracks[i - 1][k].append(
                                Message('note_on', note=note_list[i - 1][j], velocity=velocity_list[i - 1][j],
                                        time=time_list[i - 1][j]))
                        print("\nMelody instrument num: ", ins_num[instrument_list[i][k] - 1])

    print("\n--------Generating Final Output Midi File Of MuseLab and Checking the Output File Name----------")
    Filename = "MuseLab_Song_IC.mid"
    Filename = check_filename_available(Filename)
    New_mid.save('./music/Output/Instrument_Change/' + Filename)
    File_Position = './music/Output/Instrument_Change/' + Filename
    MuseScore = check_Sys_and_Open_File(File_Position)
    print("---------Done of Creating a New Midi File According to all the Messages MuseLab created---------\n")

    return MuseScore
    # Open the output through MuseScore in different system
