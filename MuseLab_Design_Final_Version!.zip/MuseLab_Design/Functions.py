import random
import os
import platform
import numpy as np
from music21 import *
from mido import MidiFile, tempo2bpm, bpm2tempo
import math
import pandas as pd


# -----------------------------------------------Data Part------------------------------------------------------
def get_tempo(file_path):
    """

    :param file_path:
    :return:
    """
    mid = MidiFile(file_path)
    for i in range(len(mid.tracks)):
        for msg in mid.tracks[i]:
            if msg.type == 'set_tempo':
                Tempo = msg.tempo
                return Tempo


def get_key_name(file_path):
    """

    :param file_path:
    :return:
    """
    k = ''
    mid = MidiFile(file_path)
    # print("Input_mid_Info: ", mid)
    for i in range(len(mid.tracks)):
        for msg in mid.tracks[i]:
            if msg.type == 'key_signature':
                k = msg.key
    return k


def get_track_num(file_path):
    """

    :param file_path: Input Midi file
    :return: Total Track Number
    """
    mid = MidiFile(file_path)
    return int(len(mid.tracks))


def get_midi_info(file_path, Type):
    """

    :param file_path:
    :param Type:
    :return:
    """
    mid = MidiFile(file_path)
    list_c, list_n, list_v, list_t, channel_list, note_list, velocity_list, time_list = \
        [], [], [], [], [], [], [], []
    # -----------Grab the useful message from original midi file, Note number, Key, Key signature, Tempo --------
    for i in range(len(mid.tracks)):
        for msg in mid.tracks[i]:
            if msg.type == 'note_on' or msg.type == 'note_off':
                list_c.append(msg.channel)
                list_n.append(msg.note)
                list_v.append(msg.velocity)
                list_t.append(msg.time)
        note_list.append(list_n)
        channel_list.append(list_c)
        velocity_list.append(list_v)
        time_list.append(list_t)
        list_n, list_t, list_c, list_v = [], [], [], []
    try:
        if Type == 'note':
            return note_list
        elif Type == 'velocity':
            return velocity_list
        elif Type == 'time':
            return time_list
        elif Type == 'channel':
            return channel_list
    except Type != 'note' and Type != 'velocity' and Type != 'time' and Type != 'channel':
        print("Type Error, Please Check 'Type' when using get_midi_info")
    else:
        print("get midi info success")


def get_MuseType_info(Type):
    """

    :param Type:
    :return:
    """
    ins_name_list = []
    file_list = open("Muse_Type.txt", "r")
    for line in file_list.readlines():
        for i in range(len(line)):
            if line[i] == '*':
                name = ''
                j = i
                k = 0
                while j > 0:
                    name += line[k]
                    j -= 1
                    k += 1
                ins_name_list.append(name)
    # print(ins_name_list)
    if Type == 'name':
        return ins_name_list


def get_txt_info(Type):
    """

    :param Type:
    :return: Instruments_list with name and number that muselab suppot, Input tempo, instrument name, instrument number
             and Track number.
    """
    ins_num_list, ins_name_list = [], []
    instruments_txt = open("instruments.txt", "r")
    for line in instruments_txt.readlines():
        for i in range(len(line)):
            if line[i] == ',':
                if line[i + 2] == '\n':
                    ins_num_list.append(int(line[i + 1]))
                elif line[i + 3] == "\n":
                    ins_num_list.append((int(line[i + 1])) * 10 + (int(line[i + 2])))
                else:
                    ins_num_list.append((int(line[i + 1])) * 100 + (int(line[i + 2])) * 10 + (int(line[i + 3])))
            elif line[i] == '*':
                try:
                    name = ''
                    j = i
                    k = 0
                    while j > 0:
                        name += line[k]
                        j -= 1
                        k += 1
                    ins_name_list.append(name)
                except BaseException as e:
                    print(e)

    All_list, Track_list, Instrument_list, Input_ins_num =[], [], [], []
    num = 0
    Input_info = open("Input_info.txt", "r")
    for line in Input_info.readlines():
        name = ''
        for i in range(len(line)):
            if line[i] != '*':
              name += line[i]
            elif line[i] == '*':
                All_list.append(name)
                name = ''
    for i in range(len(All_list)):
        str1 = All_list[i][:5]

        if str1 == 'Track':
            Track_list.append(All_list[i])
        try:
            if float(All_list[i][:2]):
                Instrument_list.append(All_list[i])
        except ValueError:
            pass

    for i in range(len(Instrument_list)):
        if Instrument_list[i][1] == '.':
            num = int(Instrument_list[i][0])
            Input_ins_num.append(num)
        if Instrument_list[i][2] == '.':
            num = int(Instrument_list[i][1]) + int(Instrument_list[i][0])*10
            Input_ins_num.append(num)
        if Instrument_list[i][3] == '.':
            num = int(Instrument_list[i][2]) + int(Instrument_list[i][1])*10 + int(Instrument_list[i][0])*100
            Input_ins_num.append(num)

    # print("Original program number for each track:", Input_ins_num)
    for i in range(len(Input_ins_num)):
        for j in range(len(ins_num_list)):
            if Input_ins_num[i] == ins_num_list[j]:
                Input_ins_num[i] = j+1
                break
    # print("Original instrument for each track:", Input_ins_num)

    if Type == 'name':
        return ins_name_list
    elif Type == 'num':
        return ins_num_list
    elif Type == 'track':
        return Track_list
    elif Type == "instrument":
        return Instrument_list
    elif Type == 'input_ins_num':
        return Input_ins_num


# for getting real name of instruments and show on screen
def get_Instrument_Name(Ins_num):
    """

    :param Ins_num: Instrument number, for getting real name of instruments and show on screen
    :return: Instrument name as string type
    """
    ins = 'instrument'
    ins_list = get_txt_info('name')
    ins_num_list = get_txt_info('num')
    for i in range(len(ins_num_list)):
        if ins_num_list[i] == Ins_num:
            ins = str(ins_list[i])
    ins = ins[3:]
    ins = ins.replace(' ', '')
    return ins

# Writing information into Input_info.txt for Change_Instrument button
def input_Msg_to_File(fp):
    """
    :param fp: Input_File_Path
    :return: No return but Input_info.txt will be refreshed
    """
    track_num = get_track_num(fp)
    with open('Input_info.txt', 'w') as f:
        for i in range(track_num):
            f.write('Track ' + str(i + 1) + '*' + '\n')
    mid = MidiFile(fp)
    print(mid)
    with open('Input_info.txt', 'a') as f:
        for message in mid:
            if message.type == 'program_change':
                Ins_name = get_Instrument_Name(int(message.program))
                f.write(str(message.program) + '. ' + Ins_name + '*' + '\n')

    tempo = round(tempo2bpm(get_tempo(fp)))
    with open('Input_info.txt', 'a') as f:
        f.write('Tempo: ' + str(tempo) + '*' + '\n')


def get_Rhythm_info():
    """
    Rhythm Type from Rhythm_Type.txt
    """
    Rhythm_type_list = []
    file_list = open("Rhythm_Type.txt", "r")
    for line in file_list.readlines():
        for i in range(len(line)):
            if line[i] == '*':
                try:
                    name = ''
                    j = i
                    k = 0
                    while j > 0:
                        name += line[k]
                        j -= 1
                        k += 1
                    Rhythm_type_list.append(name)
                except BaseException as e:
                    print(e)
    return Rhythm_type_list


def check_Sys_and_Open_File(Output_Position):
    """

    :param Output_Position:
    :return:
    """
    print("Computer System: ", platform.system())
    MuseScore = 0
    system_name = platform.system()
    if system_name == "Windows":
        import win32api
        try:
            f = win32api.ShellExecute(0, 'open', 'MuseScore3.exe', Output_Position, '', 1)
        except BaseException as e:
            MuseScore = 0
            # Debug
            print(e)
            print("MuseScore:", MuseScore)
            print("Open MuseScore Failed")
        else:
            # print("f：", f)
            if f == 42:
                MuseScore = 1
                print("MuseScore:", MuseScore)
                print("Open MuseScore Successfully")
            else:
                MuseScore = 0
                print("MuseScore:", MuseScore)
                print("Open MuseScore Failed")
        finally:
            print("Wish You Good Luck")

    elif system_name == "Darwin":
        try:
            f = os.system("open -a MuseScore\ 3 " + Output_Position)
        except BaseException:
            MuseScore = 0
            # Debug
            print(MuseScore)
            print("Open MuseScore Failed")
        else:
            # print(f)
            if f == 0:
                MuseScore = 1
                print("Open MuseScore Successfully")
            else:
                MuseScore = 0
                print("Open MuseScore Failed")
        finally:
            print("Wish You Good Luck")
    else:
        print("Please use this Application in Windows or Darwin/Mac system to have a better use.")

    return MuseScore


def check_filename_available(filename, Function_Type):
    """

    :param Function_Type:
    :param filename:
    :return:
    """
    n = [0]
    print("Type:", Function_Type )
    def check_meta(file_name, Type):
        file_name_new = ''
        if Type == 'Muse Here':
            file_name_new = file_name
            if os.path.isfile("./music/Output/Muse_Here/" + file_name):
                file_name_new = file_name[:file_name.rfind('.')] + '_' + str(n[0]) + file_name[file_name.rfind('.'):]
                n[0] += 1
            if os.path.isfile("./music/Output/Muse_Here/" + file_name_new):
                # print("file_name_new: ", file_name_new)
                file_name_new = check_meta(file_name, Type)

        elif Type == 'Playground':
            file_name_new = file_name
            if os.path.isfile("./music/Output/Playground/" + file_name):
                file_name_new = file_name[:file_name.rfind('.')] + '_' + str(n[0]) + file_name[file_name.rfind('.'):]
                n[0] += 1
            if os.path.isfile("./music/Output/Playground/" + file_name_new):
                # print("file_name_new: ", file_name_new)
                file_name_new = check_meta(file_name, Type)

        elif Type == 'Instrument change':
            file_name_new = file_name
            if os.path.isfile("./music/Output/Instrument_Change/" + file_name):
                file_name_new = file_name[:file_name.rfind('.')] + '_' + str(n[0]) + file_name[file_name.rfind('.'):]
                n[0] += 1
            if os.path.isfile("./music/Output/Instrument_Change/" + file_name_new):
                # print("file_name_new: ", file_name_new)
                file_name_new = check_meta(file_name, Type)

        return file_name_new

    return_name = check_meta(filename, Function_Type)
    print("New_File_Name: ", return_name)
    return return_name


# -----------------------------------------------Music Part---------------------------------------------------

def Random():
    """

    :return:
    """
    Random_Num = random.randint(1, 9)
    if Random_Num == 1 or Random_Num == 2 or Random_Num == 3:
        Random_Num = 3
    if Random_Num == 4 or Random_Num == 5:
        Random_Num = 5
    if Random_Num == 6 or Random_Num == 7:
        Random_Num = 6
    if Random_Num == 8 or Random_Num == 9:
        Random_Num = 8
    return Random_Num


def Get_SolFa_Name_Order(file_path):
    """

    :param file_path:
    :return:
    """
    s = converter.parse(file_path)
    mid = MidiFile(file_path)

    list_n = []
    note_list = []
    # print(mid)
    # --------------------------------Grab the note number from original midi file------------------------------------
    for i in range(len(mid.tracks)):
        for msg in mid.tracks[i]:
            if msg.type == 'note_on' or msg.type == 'note_off':
                list_n.append(msg.note)
                # C-A(m3),D-B(m3),E-C(M3),F-D(m3),G-E(m3),A-F(M3),B-G(M3) m3: -3 M3:-4
        note_list.append(list_n)
    # ------------------------------Change the note number by some musical rules for adding the base------------------
    do_list, re_list, mi_list, fa_list, so_list, la_list, si_list = [], [], [], [], [], [], []
    all_list, order_list = [], []
    input_key = s.analyze('key')
    input_key.tonic.name = get_key_name(file_path)
    # print("SolFa_Name.py key name and mode:")
    # print(input_key.tonic.name, input_key.mode)
    # key.mode = 'major'
    if input_key.tonic.name == 'C' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 0:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 2:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 4 or note_list[0][j] % 12 == 3:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 5:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 7:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 9 or note_list[0][j] % 12 == 8:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 11 or note_list[0][j] % 12 == 10:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'C+' or input_key.tonic.name == 'D-') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 1:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 3:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 5 or note_list[0][j] % 12 == 4:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 6:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 8:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 10 or note_list[0][j] % 12 == 9:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 0 or note_list[0][j] % 12 == 11:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if input_key.tonic.name == 'D' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 2:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 4:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 6 or note_list[0][j] % 12 == 5:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 7:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 9:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 11 or note_list[0][j] % 12 == 10:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 1 or note_list[0][j] % 12 == 0:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'D+' or input_key.tonic.name == 'E-') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 3:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 5:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 7 or note_list[0][j] % 12 == 6:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 8:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 10:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 0 or note_list[0][j] % 12 == 11:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 2 or note_list[0][j] % 12 == 1:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if input_key.tonic.name == 'E' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 4:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 6:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 8 or note_list[0][j] % 12 == 7:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 9:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 11:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 1 or note_list[0][j] % 12 == 0:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 3 or note_list[0][j] % 12 == 2:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'E+' or input_key.tonic.name == 'F') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 5:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 7:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 9 or note_list[0][j] % 12 == 8:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 10:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 0:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 2 or note_list[0][j] % 12 == 1:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 4 or note_list[0][j] % 12 == 3:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'F+' or input_key.tonic.name == 'G-') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 6:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 8:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 10 or note_list[0][j] % 12 == 9:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 11:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 1:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 3 or note_list[0][j] % 12 == 2:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 5 or note_list[0][j] % 12 == 4:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if input_key.tonic.name == 'G' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        # print("YEAH")
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 7:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 9:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 11 or note_list[0][j] % 12 == 10:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 0:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 2:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 4 or note_list[0][j] % 12 == 3:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 6 or note_list[0][j] % 12 == 5:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'G+' or input_key.tonic.name == 'A-') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 8:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 10:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 0 or note_list[0][j] % 12 == 11:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 1:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 3:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 5 or note_list[0][j] % 12 == 4:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 7 or note_list[0][j] % 12 == 6:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if input_key.tonic.name == 'A' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 9:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 11:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 1 or note_list[0][j] % 12 == 0:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 2:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 4:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 6 or note_list[0][j] % 12 == 5:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 8 or note_list[0][j] % 12 == 7:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if (input_key.tonic.name == 'A+' or input_key.tonic.name == 'B-') and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):
        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 10:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 0:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 2 or note_list[0][j] % 12 == 1:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 3:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 5:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 7 or note_list[0][j] % 12 == 6:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 9 or note_list[0][j] % 12 == 8:
                si_list.append(note_list[0][j])
                order_list.append(7)

    if input_key.tonic.name == 'B' and \
            ((input_key.mode == 'major') or (input_key.mode == 'minor')):

        for j in range(len(note_list[0])):
            if note_list[0][j] % 12 == 11:
                do_list.append(note_list[0][j])
                order_list.append(1)
            elif note_list[0][j] % 12 == 1:
                re_list.append(note_list[0][j])
                order_list.append(2)
            elif note_list[0][j] % 12 == 3 or note_list[0][j] % 12 == 2:
                mi_list.append(note_list[0][j])
                order_list.append(3)
            elif note_list[0][j] % 12 == 4:
                fa_list.append(note_list[0][j])
                order_list.append(4)
            elif note_list[0][j] % 12 == 6:
                so_list.append(note_list[0][j])
                order_list.append(5)
            elif note_list[0][j] % 12 == 8 or note_list[0][j] % 12 == 7:
                la_list.append(note_list[0][j])
                order_list.append(6)
            elif note_list[0][j] % 12 == 10 or note_list[0][j] % 12 == 9:
                si_list.append(note_list[0][j])
                order_list.append(7)

    all_list.append(do_list)
    all_list.append(re_list)
    all_list.append(mi_list)
    all_list.append(fa_list)
    all_list.append(so_list)
    all_list.append(la_list)
    all_list.append(si_list)
    all_list.append(order_list)
    return all_list


def SolFa_to_Melody(Note_SolFaNameList):
    """

    :param Note_SolFaNameList:
    :return:
    """
    Note_List = []
    for i in range(len(Note_SolFaNameList[7])):
        if Note_SolFaNameList[7][i] == 1:
            Note_List.append(Note_SolFaNameList[0].pop(0))
        elif Note_SolFaNameList[7][i] == 2:
            Note_List.append(Note_SolFaNameList[1].pop(0))
        elif Note_SolFaNameList[7][i] == 3:
            Note_List.append(Note_SolFaNameList[2].pop(0))
        elif Note_SolFaNameList[7][i] == 4:
            Note_List.append(Note_SolFaNameList[3].pop(0))
        elif Note_SolFaNameList[7][i] == 5:
            Note_List.append(Note_SolFaNameList[4].pop(0))
        elif Note_SolFaNameList[7][i] == 6:
            Note_List.append(Note_SolFaNameList[5].pop(0))
        elif Note_SolFaNameList[7][i] == 7:
            Note_List.append(Note_SolFaNameList[6].pop(0))

    return Note_List


def Current_SolFa_Name(input_melody_key, key_mode, note_num):
    """

    :param input_melody_key:
    :param key_mode:
    :param note_num:
    :return:
    """
    SolFa_num = 0
    if input_melody_key == 'C' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 0:
            SolFa_num = 1
        elif note_num % 12 == 2:
            SolFa_num = 2
        elif note_num % 12 == 4 or note_num % 12 == 3:
            SolFa_num = 3
        elif note_num % 12 == 5:
            SolFa_num = 4
        elif note_num % 12 == 7:
            SolFa_num = 5
        elif note_num % 12 == 9 or note_num % 12 == 8:
            SolFa_num = 6
        elif note_num % 12 == 11 or note_num % 12 == 10:
            SolFa_num = 7

    if (input_melody_key == 'C+' or input_melody_key == 'D-') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 1:
            SolFa_num = 1
        elif note_num % 12 == 3:
            SolFa_num = 2
        elif note_num % 12 == 5 or note_num % 12 == 4:
            SolFa_num = 3
        elif note_num % 12 == 6:
            SolFa_num = 4
        elif note_num % 12 == 8:
            SolFa_num = 5
        elif note_num % 12 == 10 or note_num % 12 == 9:
            SolFa_num = 6
        elif note_num % 12 == 0 or note_num % 12 == 11:
            SolFa_num = 7

    if input_melody_key == 'D' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 2:
            SolFa_num = 1
        elif note_num % 12 == 4:
            SolFa_num = 2
        elif note_num % 12 == 6 or note_num % 12 == 5:
            SolFa_num = 3
        elif note_num % 12 == 7:
            SolFa_num = 4
        elif note_num % 12 == 9:
            SolFa_num = 5
        elif note_num % 12 == 11 or note_num % 12 == 10:
            SolFa_num = 6
        elif note_num % 12 == 1 or note_num % 12 == 0:
            SolFa_num = 7

    if (input_melody_key == 'D+' or input_melody_key == 'E-') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 3:
            SolFa_num = 1
        elif note_num % 12 == 5:
            SolFa_num = 2
        elif note_num % 12 == 7 or note_num % 12 == 6:
            SolFa_num = 3
        elif note_num % 12 == 8:
            SolFa_num = 4
        elif note_num % 12 == 10:
            SolFa_num = 5
        elif note_num % 12 == 0 or note_num % 12 == 11:
            SolFa_num = 6
        elif note_num % 12 == 2 or note_num % 12 == 1:
            SolFa_num = 7

    if input_melody_key == 'E' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 4:
            SolFa_num = 1
        elif note_num % 12 == 6:
            SolFa_num = 2
        elif note_num % 12 == 8 or note_num % 12 == 7:
            SolFa_num = 3
        elif note_num % 12 == 9:
            SolFa_num = 4
        elif note_num % 12 == 11:
            SolFa_num = 5
        elif note_num % 12 == 1 or note_num % 12 == 0:
            SolFa_num = 6
        elif note_num % 12 == 3 or note_num % 12 == 2:
            SolFa_num = 7

    if (input_melody_key == 'E+' or input_melody_key == 'F') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 5:
            SolFa_num = 1
        elif note_num % 12 == 7:
            SolFa_num = 2
        elif note_num % 12 == 9 or note_num % 12 == 8:
            SolFa_num = 3
        elif note_num % 12 == 10:
            SolFa_num = 4
        elif note_num % 12 == 0:
            SolFa_num = 5
        elif note_num % 12 == 2 or note_num % 12 == 1:
            SolFa_num = 6
        elif note_num % 12 == 4 or note_num % 12 == 3:
            SolFa_num = 7

    if (input_melody_key == 'F+' or input_melody_key == 'G-') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 6:
            SolFa_num = 1
        elif note_num % 12 == 8:
            SolFa_num = 2
        elif note_num % 12 == 10 or note_num % 12 == 9:
            SolFa_num = 3
        elif note_num % 12 == 11:
            SolFa_num = 4
        elif note_num % 12 == 1:
            SolFa_num = 5
        elif note_num % 12 == 3 or note_num % 12 == 2:
            SolFa_num = 6
        elif note_num % 12 == 5 or note_num % 12 == 4:
            SolFa_num = 7

    if input_melody_key == 'G' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 7:
            SolFa_num = 1
        elif note_num % 12 == 9:
            SolFa_num = 2
        elif note_num % 12 == 11 or note_num % 12 == 10:
            SolFa_num = 3
        elif note_num % 12 == 0:
            SolFa_num = 4
        elif note_num % 12 == 2:
            SolFa_num = 5
        elif note_num % 12 == 4 or note_num % 12 == 3:
            SolFa_num = 6
        elif note_num % 12 == 6 or note_num % 12 == 5:
            SolFa_num = 7

    if (input_melody_key == 'G+' or input_melody_key == 'A-') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 8:
            SolFa_num = 1
        elif note_num % 12 == 10:
            SolFa_num = 2
        elif note_num % 12 == 0 or note_num % 12 == 11:
            SolFa_num = 3
        elif note_num % 12 == 1:
            SolFa_num = 4
        elif note_num % 12 == 3:
            SolFa_num = 5
        elif note_num % 12 == 5 or note_num % 12 == 4:
            SolFa_num = 6
        elif note_num % 12 == 7 or note_num % 12 == 6:
            SolFa_num = 7

    if input_melody_key == 'A' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 9:
            SolFa_num = 1
        elif note_num % 12 == 11:
            SolFa_num = 2
        elif note_num % 12 == 1 or note_num % 12 == 0:
            SolFa_num = 3
        elif note_num % 12 == 2:
            SolFa_num = 4
        elif note_num % 12 == 4:
            SolFa_num = 5
        elif note_num % 12 == 6 or note_num % 12 == 5:
            SolFa_num = 6
        elif note_num % 12 == 8 or note_num % 12 == 7:
            SolFa_num = 7

    if (input_melody_key == 'A+' or input_melody_key == 'B-') and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 10:
            SolFa_num = 1
        elif note_num % 12 == 0:
            SolFa_num = 2
        elif note_num % 12 == 2 or note_num % 12 == 1:
            SolFa_num = 3
        elif note_num % 12 == 3:
            SolFa_num = 4
        elif note_num % 12 == 5:
            SolFa_num = 5
        elif note_num % 12 == 7 or note_num % 12 == 6:
            SolFa_num = 6
        elif note_num % 12 == 9 or note_num % 12 == 8:
            SolFa_num = 7

    if input_melody_key == 'B' and ((key_mode == 'major') or (key_mode == 'minor')):
        if note_num % 12 == 11:
            SolFa_num = 1
        elif note_num % 12 == 1:
            SolFa_num = 2
        elif note_num % 12 == 3 or note_num % 12 == 2:
            SolFa_num = 3
        elif note_num % 12 == 4:
            SolFa_num = 4
        elif note_num % 12 == 6:
            SolFa_num = 5
        elif note_num % 12 == 8 or note_num % 12 == 7:
            SolFa_num = 6
        elif note_num % 12 == 10 or note_num % 12 == 9:
            SolFa_num = 7

    return SolFa_num


# SolFa_List can get from SolFa_List = Get_SolFa_Name_Order(file_path)
def get_cur_note_no(SolFa_List, i):
    """

    :param SolFa_List:
    :param i:
    :return:
    """
    list1 = SolFa_List
    if list1[7][i] == 1:
        x = list1[7][:i].count(1)  # counts number of 1's inside from start to i
        print("val: ", x)
        return list1[0][x]
    elif list1[7][i] == 2:
        x = list1[7][:i].count(2)
        print("val: ", x)
        return list1[1][x]
    elif list1[7][i] == 3:
        x = list1[7][:i].count(3)
        print("val: ", x)
        return list1[2][x]
    elif list1[7][i] == 4:
        x = list1[7][:i].count(4)
        print("val: ", x)
        return list1[3][x]
    elif list1[7][i] == 5:
        x = list1[7][:i].count(5)
        print("val: ", x)
        return list1[4][x]
    elif list1[7][i] == 6:
        x = list1[7][:i].count(6)
        print("val: ", x)
        return list1[5][x]
    elif list1[7][i] == 7:
        x = list1[7][:i].count(7)
        print("val: ", x)
        return list1[6][x]


def Leading_Tone(note_list, SolFa_list):
    """

    :param note_list:
    :param SolFa_list:
    :return:
    """
    # 将leading note 保持在一个区域，配合counter melody 的紧密性
    List1 = note_list
    List2 = SolFa_list
    i = len(List1[0]) - 4
    F = note_list[0][i]
    # print("HALO")
    # print(List1[0][i])
    # Take G Major as a bass line.
    if List2[7][i] == 1:
        if int(List1[0][i] / 12) - 1 == 3:  # C3 area
            List1[0][i] -= 1
        elif int(List1[0][i] / 12) - 1 == 4:  # C4 area
            List1[0][i] -= 13
        elif int(List1[0][i] / 12) - 1 == 5:  # C5 area
            List1[0][i] -= 25
        elif int(List1[0][i] / 12) - 1 == 6:  # C6 area
            List1[0][i] -= 37
        elif int(List1[0][i] / 12) - 1 == 7:  # C7 area
            List1[0][i] -= 49
        elif int(List1[0][i] / 12) - 1 == 8:  # C8 area
            List1[0][i] -= 61

    elif List2[7][i] == 2:
        if int(List1[0][i] / 12) - 1 == 3:  # D3 area
            List1[0][i] -= 3
        elif int(List1[0][i] / 12) - 1 == 4:  # D4 area
            List1[0][i] -= 15
        elif int(List1[0][i] / 12) - 1 == 5:  # D5 area
            List1[0][i] -= 27
        elif int(List1[0][i] / 12) - 1 == 6:  # D6 area
            List1[0][i] -= 39
        elif int(List1[0][i] / 12) - 1 == 7:  # D7 area
            List1[0][i] -= 51
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 63

    elif List2[7][i] == 3:
        if int(List1[0][i] / 12) - 1 == 3:
            List1[0][i] -= 5
        elif int(List1[0][i] / 12) - 1 == 4:
            List1[0][i] -= 17
        elif int(List1[0][i] / 12) - 1 == 5:
            List1[0][i] -= 29
        elif int(List1[0][i] / 12) - 1 == 6:
            List1[0][i] -= 41
        elif int(List1[0][i] / 12) - 1 == 7:
            List1[0][i] -= 53
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 65

    elif List2[7][i] == 4:
        if int(List1[0][i] / 12) - 1 == 4:
            List1[0][i] -= 6
        elif int(List1[0][i] / 12) - 1 == 5:
            List1[0][i] -= 18
        elif int(List1[0][i] / 12) - 1 == 6:
            List1[0][i] -= 30
        elif int(List1[0][i] / 12) - 1 == 7:
            List1[0][i] -= 42
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 54

    elif List2[7][i] == 5:
        if int(List1[0][i] / 12) - 1 == 4:
            List1[0][i] -= 8
        elif int(List1[0][i] / 12) - 1 == 5:
            List1[0][i] -= 20
        elif int(List1[0][i] / 12) - 1 == 6:
            List1[0][i] -= 32
        elif int(List1[0][i] / 12) - 1 == 7:
            List1[0][i] -= 44
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 56

    elif List2[7][i] == 6:
        if int(List1[0][i] / 12) - 1 == 4:
            List1[0][i] -= 10
        elif int(List1[0][i] / 12) - 1 == 5:
            List1[0][i] -= 22
        elif int(List1[0][i] / 12) - 1 == 6:
            List1[0][i] -= 34
        elif int(List1[0][i] / 12) - 1 == 7:
            List1[0][i] -= 46
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 58

    elif List2[7][i] == 7:
        if int(List1[0][i] / 12) - 1 == 4:
            List1[0][i] -= 12
        elif int(List1[0][i] / 12) - 1 == 5:
            List1[0][i] -= 24
        elif int(List1[0][i] / 12) - 1 == 6:
            List1[0][i] -= 36
        elif int(List1[0][i] / 12) - 1 == 7:
            List1[0][i] -= 48
        elif int(List1[0][i] / 12) - 1 == 8:
            List1[0][i] -= 60

    Leading_Num = List1[0][i]
    note_list[0][i] = F
    return Leading_Num


# Get different intervals with Order lists! do re mi fa so la si + order list
def get_3rd_intervals(file_path):
    """

    :param file_path:
    :return:
    """
    Note_SolFaNameList3rd = Get_SolFa_Name_Order(file_path)
    s = converter.parse(file_path)
    k = get_key_name(file_path)

    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    # print("Input key:", melody_key.tonic.name, melody_key.mode)
    for i in range(len(Note_SolFaNameList3rd)-1):
        j = 0
        while j < len(Note_SolFaNameList3rd[i]):
            if melody_key.mode == 'major':
                if i == 0 or i == 1 or i == 3 or i == 4:
                    if (int(Note_SolFaNameList3rd[i][j] / 12) - 1) <= 4:
                        Note_SolFaNameList3rd[i][j] -= 3
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 5:
                        Note_SolFaNameList3rd[i][j] -= 15
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 6:
                        Note_SolFaNameList3rd[i][j] -= 27
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 7:
                        Note_SolFaNameList3rd[i][j] -= 39
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 8:
                        Note_SolFaNameList3rd[i][j] -= 51
                if i == 2 or i == 5 or i == 6:
                    if (int(Note_SolFaNameList3rd[i][j] / 12) - 1) <= 4:
                        Note_SolFaNameList3rd[i][j] -= 4
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 5:
                        Note_SolFaNameList3rd[i][j] -= 16
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 6:
                        Note_SolFaNameList3rd[i][j] -= 28
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 7:
                        Note_SolFaNameList3rd[i][j] -= 40
                    elif (int(Note_SolFaNameList3rd[i][j] / 12) - 1) == 8:
                        Note_SolFaNameList3rd[i][j] -= 52
            j += 1
    return Note_SolFaNameList3rd


def get_5th_intervals(file_path):
    """

    :param file_path:
    :return:
    """
    Note_SolFaNameList5th = Get_SolFa_Name_Order(file_path)
    s = converter.parse(file_path)
    k = get_key_name(file_path)

    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    # print("Input key:", melody_key.tonic.name, melody_key.mode)
    for i in range(len(Note_SolFaNameList5th)-1):
        k = 0
        while k < len(Note_SolFaNameList5th[i]):
            # print("k",k)#debug
            if melody_key.mode == 'major' or melody_key.mode == 'minor':
                if i == 3:
                    if (int(Note_SolFaNameList5th[i][k] / 12) - 1) <= 4:
                        Note_SolFaNameList5th[i][k] -= 6
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 5:
                        Note_SolFaNameList5th[i][k] -= 18
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 6:
                        Note_SolFaNameList5th[i][k] -= 30
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 7:
                        Note_SolFaNameList5th[i][k] -= 42
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 8:
                        Note_SolFaNameList5th[i][k] -= 54
                else:
                    if (int(Note_SolFaNameList5th[i][k] / 12) - 1) <= 4:
                        Note_SolFaNameList5th[i][k] -= 7
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 5:
                        Note_SolFaNameList5th[i][k] -= 19
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 6:
                        Note_SolFaNameList5th[i][k] -= 31
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 7:
                        Note_SolFaNameList5th[i][k] -= 43
                    elif (int(Note_SolFaNameList5th[i][k] / 12) - 1) == 8:
                        Note_SolFaNameList5th[i][k] -= 55
            k += 1
    return Note_SolFaNameList5th


def get_6th_intervals(file_path):
    """

    :param file_path:
    :return:
    """
    Note_SolFaNameList6th = Get_SolFa_Name_Order(file_path)
    s = converter.parse(file_path)
    k = get_key_name(file_path)

    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    # print("Input key:", melody_key.tonic.name, melody_key.mode)

    for i in range(len(Note_SolFaNameList6th)-1):
        y = 0
        while y < len(Note_SolFaNameList6th[i]):

            if melody_key.mode == 'major':
                if i == 0 or i == 3 or i == 4:
                    if (int(Note_SolFaNameList6th[i][y] / 12) - 1) <= 4:
                        Note_SolFaNameList6th[i][y] -= 8
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 5:
                        Note_SolFaNameList6th[i][y] -= 20
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 6:
                        Note_SolFaNameList6th[i][y] -= 32
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 7:
                        Note_SolFaNameList6th[i][y] -= 44
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 8:
                        Note_SolFaNameList6th[i][y] -= 56
                else:
                    if (int(Note_SolFaNameList6th[i][y] / 12) - 1) <= 4:
                        Note_SolFaNameList6th[i][y] -= 9
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 5:
                        Note_SolFaNameList6th[i][y] -= 21
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 6:
                        Note_SolFaNameList6th[i][y] -= 33
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 7:
                        Note_SolFaNameList6th[i][y] -= 45
                    elif (int(Note_SolFaNameList6th[i][y] / 12) - 1) == 8:
                        Note_SolFaNameList6th[i][y] -= 57
            y += 1

    return Note_SolFaNameList6th


def get_8ve_intervals(file_path):
    """

    :param file_path:
    :return:
    """
    Note_SolFaNameList8ve = Get_SolFa_Name_Order(file_path)
    s = converter.parse(file_path)
    k = get_key_name(file_path)

    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    # print("Input key:", melody_key.tonic.name, melody_key.mode)

    for i in range(len(Note_SolFaNameList8ve)-1):
        x = 0
        while x < len(Note_SolFaNameList8ve[i]):
            Note_SolFaNameList8ve[i][x] -= 12
            x += 1
    return Note_SolFaNameList8ve


def get_counter_need_num(prev_c_num, cur_note_num, prev_note_num, diff_check, intervals):
    """
    :param prev_c_num: previous counter melody note number
    :param cur_note_num: current note number from input main melody
    :param prev_note_num: previous note number from input main melody
    :param diff_check: a list of distance between each to be used interval note number and previous counter melody note
    :param intervals: a list of 3rd, 5th, 6th, 8ve inntervals note number based on the current input melody note numbber
    :return: a most suitable needed number from intervals.
    """
    if cur_note_num > prev_note_num:  # ascending, need -ve notes for counter
        print("Currently ascending!")
        if min(diff_check) <= 0:
            if any(-3 <= elem < 0 for elem in diff_check):
                needed_num = diff_check.index(max([no for no in diff_check if no < 0]))
            else:
                needed_num = diff_check.index(max([no for no in diff_check if no <= 0]))
            # print("Flag")
        else:
            while min(diff_check) > 0:
                for j in range(4):
                    intervals[j] -= 12
                    diff_check[j] = intervals[j] - prev_c_num
                print(diff_check)

            if any(-3 <= elem < 0 for elem in diff_check):
                needed_num = diff_check.index(max([no for no in diff_check if no < 0]))
            else:
                needed_num = diff_check.index(max([no for no in diff_check if no <= 0]))
    else:  # descending, need +ve notes for counter
        print("Currently descending!")
        if max(diff_check) >= 0:
            if any(3 >= elem > 0 for elem in diff_check):
                needed_num = diff_check.index(min([no for no in diff_check if no > 0]))
            else:
                needed_num = diff_check.index(min([no for no in diff_check if no >= 0]))
            # print("Flag")
        else:
            while max(diff_check) < 0:
                for j in range(4):
                    intervals[j] += 12
                    diff_check[j] = intervals[j] - prev_c_num
                print(diff_check)

            if any(3 >= elem > 0 for elem in diff_check):
                needed_num = diff_check.index(min([no for no in diff_check if no > 0]))
            else:
                needed_num = diff_check.index(min([no for no in diff_check if no >= 0]))

    return needed_num


def get_counter_melody(file_path):
    """

    :param file_path:
    :return:
    """
    s = converter.parse(file_path)
    melody_key = s.analyze('key')
    # needed interval, previous_Input_number,  previous counter MIDI number
    needed_num, prev_note_num, prev_c_num = 0, 0, 0
    # checks difference between current counter notes and previous counter notes(NOT simply notes!)
    CounterMelody_List, diff_check = [], [0, 0, 0, 0]
    k = get_key_name(file_path)
    melody_key.tonic.name = k
    note_list = get_midi_info(file_path, 'note')
    # loops
    Note_SolFaNameList3rd = get_3rd_intervals(file_path)
    Note_SolFaNameList5th = get_5th_intervals(file_path)
    Note_SolFaNameList6th = get_6th_intervals(file_path)
    Note_SolFaNameList8ve = get_8ve_intervals(file_path)
    SolFa_List = Get_SolFa_Name_Order(file_path)
    print("Generating Alto/Counter Melody......")
    for i in range(len(Note_SolFaNameList3rd[7])):
        # debug
        print("i_Number: ", i)
        cur_note_num = get_cur_note_no(SolFa_List, i)  # gets the current Input MIDI number with function

        intervals = [Note_SolFaNameList3rd[SolFa_List[7][i]-1].pop(0), Note_SolFaNameList5th[SolFa_List[7][i]-1].pop(0),
                     Note_SolFaNameList6th[SolFa_List[7][i]-1].pop(0), Note_SolFaNameList8ve[SolFa_List[7][i]-1].pop(0)]
        print("intervals:", intervals)  # debug
        print("Previous_C_Num:", prev_c_num )  # debug
        # The last note should be an octave lower than main melody note, 8ve
        if i == len(SolFa_List[7]) - 2 or i == len(SolFa_List[7]) - 1:
            CounterMelody_List.append(intervals[3])
        # list for recording val. diff. of each chord(3,5,6,8), also in such order
        for j in range(4):
            diff_check[j] = (int(intervals[j]-prev_c_num))
        print("diff_check: ", diff_check)
        if i > 1:
            # print("Flag")
            needed_num = get_counter_need_num(prev_c_num, cur_note_num, prev_note_num, diff_check, intervals)
            print("needed_num: ", needed_num)
        # update previous counter melody note num after first bar with an octave lower of input melody note number.
        if i == 0 or i == 1:
            prev_c_num = intervals[3]
            CounterMelody_List.append(intervals[3])
        # normal cases
        if 1 < i < len(SolFa_List[7]) - 2:
            CounterMelody_List.append(intervals[needed_num])
            prev_c_num = CounterMelody_List[i - 1]
        print("Contrary motion num:", CounterMelody_List[i])
        # Before penultimate bar
        if (1 < i < len(SolFa_List[7]) - 4) and (i % 2 == 1):
            input_current_SolFa_name = \
                Current_SolFa_Name(input_melody_key=melody_key.tonic.name, key_mode=melody_key.mode,
                                   note_num=cur_note_num)
            counter_current_SolFa_name = \
                Current_SolFa_Name(input_melody_key=melody_key.tonic.name, key_mode=melody_key.mode,
                                   note_num=CounterMelody_List[i])
            print("input:", input_current_SolFa_name, "output:", counter_current_SolFa_name)
            differ = input_current_SolFa_name - counter_current_SolFa_name
            print("differ:", differ)
            # 尽量避免太多8ve的重复。
            if differ == 0:
                R = np.random.choice([0, 1, 2], replace=True, p=[0.4, 0.4, 0.2])
                # R = random.randint(0, 1)
                print("Random Number:", R)
                print("CounterMelody_append_Num: ")
                print(CounterMelody_List[i])
                if R == 0:
                    if counter_current_SolFa_name == 1 or counter_current_SolFa_name == 2 or \
                            counter_current_SolFa_name == 4 or counter_current_SolFa_name == 5:
                        CounterMelody_List[i - 1] -= 3
                        CounterMelody_List[i] -= 3
                        prev_c_num = CounterMelody_List[i]
                    else:
                        CounterMelody_List[i - 1] -= 4
                        CounterMelody_List[i] -= 4
                        prev_c_num = CounterMelody_List[i]
                elif R == 1:
                    if counter_current_SolFa_name == 1 or counter_current_SolFa_name == 4 \
                            or counter_current_SolFa_name == 5:
                        CounterMelody_List[i - 1] += 4
                        CounterMelody_List[i] += 4
                        prev_c_num = CounterMelody_List[i]
                    else:
                        CounterMelody_List[i - 1] += 3
                        CounterMelody_List[i] += 3
                        prev_c_num = CounterMelody_List[i]
        # leading tone for penultimate bar
        if i == len(SolFa_List[7]) - 3:
            if melody_key.mode == 'major' and \
                    (melody_key.tonic.name == 'G' or melody_key.tonic.name == 'A' or melody_key.tonic.name == 'D'):
                Leading_Num = Leading_Tone(note_list, SolFa_List)
                CounterMelody_List[i] = CounterMelody_List[i - 1] = Leading_Num
        # 避免Counter Melody 音与音直接跨度太大而导致旋律不连贯, 避免过多的重复音出现在Counter Melody
        if (1 < i < len(SolFa_List[7]) - 2) and i % 2 == 1:
            if CounterMelody_List[i] - CounterMelody_List[i - 2] > 10:
                CounterMelody_List[i] -= 12
                CounterMelody_List[i - 1] = CounterMelody_List[i]
                prev_c_num = CounterMelody_List[i]
            elif CounterMelody_List[i] - CounterMelody_List[i - 2] <= -10:
                CounterMelody_List[i] += 12
                CounterMelody_List[i - 1] = CounterMelody_List[i]
                prev_c_num = CounterMelody_List[i]
            elif CounterMelody_List[i] > note_list[0][i]:
                CounterMelody_List[i] -= 12
                CounterMelody_List[i - 1] = CounterMelody_List[i]
                prev_c_num = CounterMelody_List[i]
            elif CounterMelody_List[i] - CounterMelody_List[i - 2] == 0:
                counter_current_SolFa_name = \
                    Current_SolFa_Name(input_melody_key=melody_key.tonic.name, key_mode=melody_key.mode,
                                       note_num=CounterMelody_List[i])
                R = np.random.choice([0, 1], replace=True, p=[0.5, 0.5])
                if R == 1:
                    if counter_current_SolFa_name == 1 or counter_current_SolFa_name == 4 \
                            or counter_current_SolFa_name == 5:
                        CounterMelody_List[i - 1] += 4
                        CounterMelody_List[i] += 4
                        prev_c_num = CounterMelody_List[i]
                    else:
                        CounterMelody_List[i - 1] += 3
                        CounterMelody_List[i] += 3
                        prev_c_num = CounterMelody_List[i]

        # debugging below
        print("CounterMelody_append_Num_after: ")
        print(CounterMelody_List[i])
        print("Current note num: ")
        print(cur_note_num)
        print("Previous note num: ")
        print(prev_note_num)
        if i % 2 == 1:
            prev_note_num = cur_note_num  # update previous note number to current note number
        # print("Program ran for the ", i+1, "th time")

    # in case Counter melody beyond Input Melody
    for i in range(len(CounterMelody_List)):
        if CounterMelody_List[i] > note_list[0][i]:
            CounterMelody_List[i] -= 12

    return CounterMelody_List


def get_Bass(file_path, interval_list, Type):
    """

    :param file_path:
    :param interval_list:
    :param Type:
    :return:
    """
    Bass_t = []  # get time of long sound list
    Bass_n = []  # doubles all elements within list
    Bass_v = []  # self made velocity
    interval_note = interval_list
    time_list = get_midi_info(file_path, 'time')
    note_list = get_midi_info(file_path, 'note')
    time = 0
    bar_num = Bar_Count(time_list)
    bar_n = 1
    Bass_n.append(interval_note[0] - 24)
    Bass_n.append(interval_note[0] - 24)
    Bass_t.append(0)
    Bass_t.append(1920)
    Bass_v.append(80)
    Bass_v.append(0)

    for i in range(len(time_list[0])):
        time = time + time_list[0][i]
        if bar_n < bar_num - 1:
            if time > 1920:
                Bass_n.append(interval_note[i] - 24)
                Bass_n.append(interval_note[i] - 24)
                Bass_t.append(0)
                Bass_t.append(1920)
                Bass_v.append(80)
                Bass_v.append(0)
                bar_n += 1
                time -= 1920
        else:
            Bass_n.append(note_list[0][-1] - 36)
            Bass_n.append(note_list[0][-1] - 36)
            Bass_t.append(0)
            Bass_t.append(1920)
            Bass_v.append(80)
            Bass_v.append(0)
            break

    if Type == 'note':
        return Bass_n
    elif Type == 'time':
        return Bass_t
    elif Type == 'velocity':
        return Bass_v


def get_pre_Rhythm(file_path, instrument_type, Type):
    """

    :param file_path:
    :param instrument_type:
    :param Type:
    :return:
    """
    if instrument_type == 2:
        Rhythm_note = get_Rhythm(file_path, 4, 'note')
        Rhythm_time = get_Rhythm(file_path, 4, 'time')
        Rhythm_velocity = get_Rhythm(file_path, 4, 'velocity')
    elif instrument_type == 3 or instrument_type == 5 or instrument_type == 6:
        Rhythm_note = get_Rhythm(file_path, 15, 'note')
        Rhythm_time = get_Rhythm(file_path, 15, 'time')
        Rhythm_velocity = get_Rhythm(file_path, 15, 'velocity')
    else:
        Rhythm_note = get_Rhythm(file_path, "Null", 'note')
        Rhythm_time = get_Rhythm(file_path, "Null", 'time')
        Rhythm_velocity = get_Rhythm(file_path, "Null", 'velocity')


    print("Max and min of Rhythm note: ", max(Rhythm_note) + 12, " and ", min(Rhythm_note) + 12)
    if Type == 'note':
        return Rhythm_note
    elif Type == 'time':
        return Rhythm_time
    elif Type == 'velocity':
        return Rhythm_velocity


def get_pre_instruments(file_path, instrument_type):
    """

    :param file_path:
    :param instrument_type:
    :return:
    """
    program_l = []

    # Violin Quartet1
    if instrument_type == 1:
        program_l = [40, 41, 42, 43]
    # Piano + Melodic Drums
    elif instrument_type == 2:
        program_l = [1, 1, 117, 117]
    # Sax. + Drums
    elif instrument_type == 3:
        program_l = [64, 64, 117, 113]
    # Wind Quartet
    elif instrument_type == 4:
        program_l = [73, 68, 71, 70]
    # Brass Quartet
    elif instrument_type == 5:
        program_l = [56, 56, 117, 113]
    # Saxophone Trio
    elif instrument_type == 6:
        program_l = [64, 65, 66]
    # Pad2 + Vio.
    elif instrument_type == 7:
        program_l = [89, 89, 41, 42]

    return program_l


def get_Rhythm(file_path, RhythmType, Type):
    """

    :param file_path:
    :param RhythmType:
    :param Type:
    :return:
    """
    Note_SolFaNameList5th = get_5th_intervals(file_path)
    Bass_5th = SolFa_to_Melody(Note_SolFaNameList5th)
    Bass_note = get_Bass(file_path, Bass_5th, 'note')
    Bass_time = get_Bass(file_path, Bass_5th, 'time')
    Bass_velocity = get_Bass(file_path, Bass_5th, 'velocity')
    Rhythm_note, Rhythm_time, Rhythm_velocity = [], [], []
    Rhythm_note1, Rhythm_note2, Rhythm_note3 = [], [], []
    Rhythm_time1, Rhythm_time2, Rhythm_time3 = [], [], []
    Rhythm_velocity1, Rhythm_velocity2, Rhythm_velocity3 = [], [], []
    time_list = get_midi_info(file_path, 'time')
    bar_n = 1
    time_n = 0
    if RhythmType == 1:
        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(4):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(25)
                    elif j % 2 == 1:
                        Rhythm_time.append(455)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(25)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    # # if Rhythm half note ----
    if RhythmType == 2:

        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(2):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(49)
                    elif j % 2 == 1:
                        Rhythm_time.append(911)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(49)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    # # if Rhythm quaver/eighth note
    if RhythmType == 3:

        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(8):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(13)
                    elif j % 2 == 1:
                        Rhythm_time.append(227)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(13)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    # # if Rhythm doted half note
    if RhythmType == 4:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(4):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(683)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(4):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(37)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(25)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 5:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(42)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(678)
                        Rhythm_note.append(Bass_note[i]+12)

            else:
                if i % 2 == 0:
                    Rhythm_time.append(42)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 6:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(7):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(7):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i]+12)

            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 7:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(7):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(7):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(13)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 8:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(5):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(37)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(5):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(683)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(37)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 9:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(8):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(8):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(32)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 10:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(11):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 9:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 10:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(11):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(00)
                            Rhythm_time.append(448)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 9:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 10:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)

                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 11:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(9):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(9):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 12:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(678)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(42)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i]+12)

            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 13:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(9):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(9):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 14:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i]+12)

            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i]+12)

    if RhythmType == 15:
        # Type 2
        n1 = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(2):
                    if i == 0 and j == 0 and n1 == 1:
                        Rhythm_time1.append(0)
                        Rhythm_velocity1.append(80)
                    if j % 2 == 0 and n1 == 0:
                        Rhythm_velocity1.append(80)
                        Rhythm_time1.append(49)
                    elif j % 2 == 1:
                        Rhythm_time1.append(911)
                        Rhythm_velocity1.append(0)
                    n1 = 0
                    Rhythm_note1.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time1.append(49)
                    Rhythm_velocity1.append(80)
                else:
                    Rhythm_velocity1.append(0)
                    Rhythm_time1.append(Bass_time[i])
                Rhythm_note1.append(Bass_note[i]+12)

        # Type 1
        n2 = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(4):
                    if i == 0 and j == 0 and n2 == 1:
                        Rhythm_time2.append(0)
                        Rhythm_velocity2.append(80)
                    if j % 2 == 0 and n2 == 0:
                        Rhythm_velocity2.append(80)
                        Rhythm_time2.append(25)
                    elif j % 2 == 1:
                        Rhythm_time2.append(455)
                        Rhythm_velocity2.append(0)
                    n2 = 0
                    Rhythm_note2.append(Bass_note[i]+12)
            else:
                if i % 2 == 0:
                    Rhythm_time2.append(25)
                    Rhythm_velocity2.append(80)
                else:
                    Rhythm_velocity2.append(0)
                    Rhythm_time2.append(Bass_time[i])
                Rhythm_note2.append(Bass_note[i]+12)

        # Type 14
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(0)
                        elif j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 1:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(338)
                        elif j == 2:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(22)
                        elif j == 3:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(338)
                        elif j == 4:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(22)
                        elif j == 5:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        Rhythm_note3.append(Bass_note[i]+12)
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 1:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(448)
                        elif j == 2:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(32)
                        elif j == 3:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        elif j == 4:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 5:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        Rhythm_note3.append(Bass_note[i]+12)

            else:
                if i % 2 == 0:
                    Rhythm_time3.append(12)
                    Rhythm_velocity3.append(80)
                else:
                    Rhythm_velocity3.append(0)
                    Rhythm_time3.append(Bass_time[i])
                Rhythm_note3.append(Bass_note[i]+12)

        bar_num = Bar_Count(time_list)
        # print("1t:", Rhythm_time1)
        # print("2t:", Rhythm_time2)
        # print("3t:", Rhythm_time3)
        # print("1n:", Rhythm_note1)
        # print("2n:", Rhythm_note2)
        # print("3n:", Rhythm_note3)
        z = 0
        # print(bar_num)
        # print(Rhythm_time)
        i = 1
        while i < bar_num:
            if i < 3:
                for j in range(len(Rhythm_time1)):
                    time_n += Rhythm_time1[j]
                    # print("time:", time_n)
                    if time_n > 1920:
                        bar_n += 1
                        print("bar_n:", bar_n)
                        time_n -= 1920
                        if bar_n == 4:
                            i += 3
                            Rhythm_note.pop()
                            Rhythm_velocity.pop()
                            # print("1:", Rhythm_note)
                            # print("1:", Rhythm_time)
                            # print("1:", Rhythm_velocity)
                            bar_n = 1
                            break
                    if bar_n < 4:
                        Rhythm_note.append(Rhythm_note1[j])
                        Rhythm_velocity.append(Rhythm_velocity1[j])
                        Rhythm_time.append(Rhythm_time1[j])

            elif i == 4:
                for j in range(len(Rhythm_note2)):
                    time_n += Rhythm_time2[j]
                    if bar_n == 4:
                        Rhythm_time.append(Rhythm_time2[j+1])
                    if time_n > 1920:
                        bar_n += 1
                        time_n -= 1920
                    if bar_n == 4:
                        Rhythm_note.append(Rhythm_note2[j-1])
                        Rhythm_velocity.append(Rhythm_velocity2[j-1])
                    elif bar_n > 4:
                        # print("2:", Rhythm_note)
                        # print("2:", Rhythm_time)
                        # print("2:", Rhythm_velocity)
                        time_n = 0
                        bar_n = 1
                        i += 1
                        break
            else:
                for j in range(len(Rhythm_time3)):
                    time_n += Rhythm_time3[j]
                    if bar_n > 4 and j < len(Rhythm_note3):
                        Rhythm_time.append(Rhythm_time3[j-1])
                        z = j
                    if time_n > 1920:
                        bar_n += 1
                        i += 1
                        time_n -= 1920
                    if bar_n > 4:
                        Rhythm_note.append(Rhythm_note3[j-1])
                        Rhythm_velocity.append(Rhythm_velocity3[j-1])

                Rhythm_time.append(Rhythm_time3[z])
                Rhythm_note.append(Rhythm_note3[z])
                Rhythm_velocity.append(Rhythm_velocity3[z])
                # print("3:", Rhythm_note)
                # print("3:", Rhythm_time)
                # print("3:", Rhythm_velocity)
                # print(i)
                break

    if RhythmType == 'Null':
        for i in range(len(Bass_note)):
            Bass_note[i] += 12
        Rhythm_note = Bass_note
        Rhythm_time = Bass_time
        Rhythm_velocity = Bass_velocity

    if Type == 'note':
        return Rhythm_note
    elif Type == 'time':
        return Rhythm_time
    elif Type == 'velocity':
        return Rhythm_velocity


def Bar_Count(time_list):
    """

    :param time_list:
    :return:
    """
    time = 0
    for i in range(len(time_list[0])):
        time += time_list[0][i]
    # print("total time:", time)
    time /= 1920
    time = math.ceil(time)
    return time
