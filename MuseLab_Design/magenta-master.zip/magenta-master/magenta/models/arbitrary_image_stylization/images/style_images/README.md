Source of images:

towers_1916:
https: //www.wikiart.org/en/max-ernst/towers-1916

clouds-over-bor-1940:
https://www.wikiart.org/en/paul-klee/clouds-over-bor-1940

Theo_van_Doesburg
https://commons.wikimedia.org/wiki/File:Theo_van_Doesburg_Composition_XIII_(woman_in_studio).jpg#metadata

La_Reforma
https://usw2-uploads8.wikiart.org/images/joan-miro/not_detected_227961.jpg
https://www.wikiart.org/en/joan-miro/not_detected_227961

Camille_Mauclair
https://commons.wikimedia.org/wiki/File:Camille_Mauclair_by_Vallotton.jpg

bricks:
https://pixabay.com/en/bricks-diagonal-chevron-tiles-1448260/

black_zigzag:
https://pixabay.com/en/black-white-chevron-striped-2780587/

wood_zigzag1:
https://pixabay.com/en/wood-zigzag-design-texture-element-1973721/

zigzag_colorful
http://www.publicdomainpictures.net/view-image.php?image=100795&picture=chevrons-zigzag-colorful-background

red_texture
https://pixabay.com/en/background-texture-pattern-2462491/

piano-keyboard-sketch
http://www.publicdomainpictures.net/view-image.php?image=228262&picture=&jazyk=CN



