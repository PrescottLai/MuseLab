# Demos

Demonstrations of Magenta models can be found in the [Magenta Demos](https://github.com/tensorflow/magenta-demos) repository.