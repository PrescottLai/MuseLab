from Functions import *
from mido import Message, MidiFile, MidiTrack, MetaMessage


def Muse_Here(file_path, instrument_type):
    """

    :param file_path: 
    :param instrument_type: 
    :return: 
    """
    print("---------------------------Done of Creating Backup of Input File-------------------------------\n")

    print("------------------------------Getting Input_Midi_Information-----------------------------------")
    s = converter.parse(file_path)
    mid = MidiFile(file_path)
    k = get_key_name(file_path)
    Tempo = get_tempo(file_path)
    note_list = get_midi_info(file_path, 'note')
    velocity_list = get_midi_info(file_path, 'velocity')
    time_list = get_midi_info(file_path, 'time')
    channel_list = get_midi_info(file_path, 'channel')
    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    print("Input_mid_Info: ", mid)
    print("MIDI data: ", mid)
    print("Input key:", melody_key.tonic.name, melody_key.mode)
    print("Melody_Tempo:", Tempo)
    print("input_note:", note_list)
    print("input_time:", time_list[0])
    print("input_note:", note_list)
    print("input_velocity:", velocity_list[0])
    Bar = Bar_Count(time_list)
    print("Total Bar num:", Bar)
    for i in range(len(mid.tracks)):
        z = 0
        for msg in mid.tracks[i]:
            print(z, ":", msg)
            z += 1
    print("---------------------------Done of Getting Input_Midi_Information------------------------------\n")

    print("------------------------------Creating Different Intervals List--------------------------------")
    Note_SolFaNameList3rd, Note_SolFaNameList5th = [], []
    try:
        Note_SolFaNameList3rd = get_3rd_intervals(file_path)
        Note_SolFaNameList5th = get_5th_intervals(file_path)
        # Note_SolFaNameList6th = get_6th_intervals(file_path)
        # Note_SolFaNameList8ve = get_8ve_intervals(file_path)
    except BaseException as e:
        print("Something Get Wrong when Creating different intervals: ", e)
    else:
        print("\nGetting Intervals List Success\n")
    print("--------------------------Done of Creating Different Intervals List----------------------------\n")

    print("-----------------------------------Creating Counter Melody-------------------------------------")
    CounterMelody_List = []
    try:
        CounterMelody_List = get_counter_melody(file_path)
    except BaseException as e:
        print("Something Get Wrong when Creating Counter Melody: ", e)
    else:
        print("\nGetting Counter Melody List Success\n")

        print("N_List: ", note_list[0])
        print("V_List: ", velocity_list[0])
        print("T_List: ", time_list[0])
        print("Counter_List: ", CounterMelody_List)
        print("input_List_Length: ", len(note_list[0]))
        # print("List_Length: ", len(velocity_list[0]))
        # print("List_Length: ", len(time_list[0]))
        print("Counter_List_Length:", len(CounterMelody_List))
        print("Max and min of counter melody: ", max(CounterMelody_List), " and ", min(CounterMelody_List))
    print("-------------------------------Done of Creating Counter Melody---------------------------------\n")

    print("------------------------Create the Rhythm part which is the third track------------------------")
    # We can get the numerator and denominator in MIDI file and set the different rules.
    Rhythm_note, Rhythm_time, Rhythm_velocity = [], [], []
    try:
        Rhythm_note = get_pre_Rhythm(file_path, instrument_type, 'note')
        Rhythm_time = get_pre_Rhythm(file_path, instrument_type, 'time')
        Rhythm_velocity = get_pre_Rhythm(file_path, instrument_type, 'velocity')
    except BaseException as e:
        print("Something Get Wrong when Creating Rhythm Part: ", e)
    else:
        print("\nGetting Rhythm Lists Success\n")

        print("Instrument Type:", instrument_type)
        print("Rhythm note:", Rhythm_note)
        print("Rhythm_velocity:", Rhythm_velocity)
        print("Rhythm_time:", Rhythm_time)
        print("Rhythm_note_length: ", len(Rhythm_note))
        print("Rhythm_velocity_length: ", len(Rhythm_velocity))
        print("Rhythm_time_length: ", len(Rhythm_time))
    print("-----------------Done Of Create the Rhythm part which is the third track-----------------------\n")

    print("------------------Create the Bass part which is the forth track with long notes----------------")
    Bass_5th, Bass_note, Bass_time, Bass_velocity = [], [], [], []
    try:
        Bass_5th = SolFa_to_Melody(Note_SolFaNameList5th)
        Bass_note = get_Bass(file_path, Bass_5th, 'note')
        Bass_time = get_Bass(file_path, Bass_5th, 'time')
        Bass_velocity = get_Bass(file_path, Bass_5th, 'velocity')
    except BaseException as e:
        print("Something Get Wrong when Creating Bass Part: ", e)
    else:
        print("\nGetting Bass Lists Success\n")

        print("5th intervals notes:", Bass_5th)
        print("Bass Note: ", Bass_note)
        print("Bass Velocity: ", Bass_velocity)
        print("Bass Time: ", Bass_time)
        print("Bass Note length: ", len(Bass_note))
        print("Max and min of Bass_note: ", max(Bass_note), " and ", min(Bass_note))
        print("Max and min of original note list: ", max(note_list[0]), " and ", min(note_list[0]))
    print("-------------Done of Create the Bass Part which is the Forth Track with Long Notes-------------\n")

    print("------------Getting Instruments Number for Output MIDI File Based on User's Choice-------------")
    program_l = []
    try:
        program_l = get_pre_instruments(file_path, instrument_type)
    except BaseException as e:
        print("Something Get Wrong when Getting instruments Number: ", e)
    else:
        print("\nGetting Instruments Number List Success\n")

        print("Instrument type: ", instrument_type)
        print("Program_List: ", program_l)

    print("---------Done of Getting Instruments Number for Output MIDI File Based on User's Choice--------\n")

    print("------------Creating a New Midi File According to all the Messages MuseLab created-------------")

    track1 = MidiTrack()
    track2 = MidiTrack()
    track3 = MidiTrack()
    track4 = MidiTrack()
    New_mid = MidiFile()
    New_mid.tracks.append(track1)
    New_mid.tracks.append(track2)
    New_mid.tracks.append(track3)
    New_mid.tracks.append(track4)

    print("------Generating Part 1 Tracks Part 1 which is Melody Part-----\n")
    track1.append(Message('program_change', channel=0, program=program_l[0], time=0))
    track1.append(MetaMessage('set_tempo', tempo=Tempo, time=0))
    for j in range(len(channel_list[0])):
        track1.append(Message('note_on', note=note_list[0][j], velocity=velocity_list[0][j], time=time_list[0][j]))

    print("------Generating Part 2 Tracks which is Counter Melody Part-----\n")
    track2.append(Message('program_change', channel=0, program=program_l[1], time=0))
    track2.append(MetaMessage('set_tempo', tempo=Tempo, time=0))
    for j in range(len(CounterMelody_List)):
        if j % 2 == 0:
            track2.append(
                Message('note_on', note=CounterMelody_List[j], velocity=velocity_list[0][j] - 20, time=time_list[0][j]))
        else:
            track2.append(
                Message('note_on', note=CounterMelody_List[j], velocity=velocity_list[0][j], time=time_list[0][j]))

    print("----------Generating Part 3 Tracks which is Rhythm Part--------\n")
    track3.append(Message('program_change', channel=0, program=program_l[2], time=0))
    track3.append(MetaMessage('set_tempo', tempo=Tempo, time=0))
    if program_l[2] == 10:
        for k in range(len(Rhythm_note)):
            Rhythm_note[k] += 48
    elif program_l[2] == 117 or program_l[2] == 107:
        for k in range(len(Rhythm_note)):
            Rhythm_note[k] += 12
    for j in range(len(Rhythm_note)):
        if j % 2 == 0:
            track3.append(
                Message('note_on', note=Rhythm_note[j], velocity=Rhythm_velocity[j] - 20, time=Rhythm_time[j]))
        else:
            track3.append(
                Message('note_on', note=Rhythm_note[j], velocity=Rhythm_velocity[j], time=Rhythm_time[j]))

    print("----------Generating Part 4 Tracks which is Bass Part--------\n")
    if len(program_l) == 4:
        track4.append(Message('program_change', channel=0, program=program_l[3], time=0))
        track4.append(MetaMessage('set_tempo', tempo=Tempo, time=0))
        if program_l[3] == 10:
            for k in range(len(Bass_note)):
                Bass_note[k] += 60
        elif program_l[3] == 117:
            for k in range(len(Bass_note)):
                Bass_note[k] += 24
        elif program_l[3] == 66:
            for k in range(len(Bass_note)):
                Bass_note[k] += 12
        for j in range(len(Bass_note)):
            if j % 2 == 0:
                track4.append(
                    Message('note_on', note=Bass_note[j], velocity=Bass_velocity[j] - 10, time=Bass_time[j]))
            else:
                track4.append(
                    Message('note_on', note=Bass_note[j], velocity=Bass_velocity[j], time=Bass_time[j]))

    print("--------Generating Final Output Midi File Of MuseLab and Checking the Output File Name----------")
    Filename = "MuseLab_Song_MH.mid"
    Filename = check_filename_available(Filename)
    New_mid.save('./music/Output/' + Filename)
    Output_Position = './music/Output/' + Filename
    MuseScore = check_Sys_and_Open_File(Output_Position)

    print("---------Done of Creating a New Midi File According to all the Messages MuseLab created---------\n")

    return MuseScore
