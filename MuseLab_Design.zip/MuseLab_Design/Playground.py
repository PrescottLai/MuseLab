from Add_BaseChord import *
from Functions import *
from mido import MetaMessage


def Own_Creation(file_path, instrument_List):
    mid = MidiFile(file_path)
    print("Input_mid_Info: ", mid)
    print("MIDI data: ", mid)
    print("Mid_Track_Length: ", len(mid.tracks))
    s = converter.parse(file_path)
    Input_File = "Input.mid"
    Input_File_name = check_filename_available(Input_File)
    s.write("midi", "./music/Output/" + Input_File_name)

    # -----------Grab the useful message from original midi file, Note number, Key, Key signature, Tempo --------
    k = get_key_name(file_path)
    Tempo = get_tempo(file_path)
    note_list = get_midi_info(file_path, 'note')
    velocity_list = get_midi_info(file_path, 'velocity')
    time_list = get_midi_info(file_path, 'time')
    channel_list = get_midi_info(file_path, 'channel')
    melody_key = s.analyze('key')
    melody_key.tonic.name = k
    print("Input key:", melody_key.tonic.name, melody_key.mode)
    print("Melody_Tempo:", Tempo)
    print("input_note:", note_list)
    print("input_time:", time_list[0])
    # -----------Grab the useful message from original midi file, Note number, Key, Key signature, Tempo --------
    
    # -------------------------------Create Lists of intervals 3rd & 5th & 6th & 8ve----------------------------
    Note_SolFaNameList3rd = get_3rd_intervals(file_path)
    # Note_SolFaNameList5th = get_5th_intervals(file_path)
    # Note_SolFaNameList6th = get_6th_intervals(file_path)
    # Note_SolFaNameList8ve = get_8ve_intervals(file_path)
    # -------------------------------Create Lists of intervals 3rd & 5th & 6th & 8ve----------------------------
    
    # ---------------------------------Generate the Counter melody part----------------------------------------
    CounterMelody_List = get_counter_melody(file_path)
    print("N_List: ", note_list[0])
    print("V_List: ", velocity_list[0])
    print("T_List: ", time_list[0])
    print("Counter_List: ", CounterMelody_List)

    print("List_Length: ", len(note_list[0]))
    print("List_Length: ", len(velocity_list[0]))
    print("List_Length: ", len(time_list[0]))
    print("Counter_List_Length:", len(CounterMelody_List))
    print("Max and min of counter melody: ", max(CounterMelody_List), " and ", min(CounterMelody_List))
    # ---------------------------------Generate the Counter melody part----------------------------------------

    # ------------------------------Build Rhythm part for track3---------------------------------------------
    print("Generating Rhythm part......")
    print("instrument_length:", len(instrument_List))
    print("Rhythm Type:", instrument_List[5])
    if len(instrument_List) == 6:
        Rhythm_note = get_Rhythm(file_path, instrument_List[5], 'note')
        Rhythm_time = get_Rhythm(file_path, instrument_List[5], 'time')
        Rhythm_velocity = get_Rhythm(file_path, instrument_List[5], 'velocity')
    print("Rhythm note:", Rhythm_note)
    print("Rhythm_velocity:", Rhythm_velocity)
    print("Rhythm_time:", Rhythm_time)
    print("Rhythm_note_length: ", len(Rhythm_note))
    print("Rhythm_velocity_length: ", len(Rhythm_velocity))
    print("Rhythm_time_length: ", len(Rhythm_time))
    # ------------------------------Build Rhythm part for track3---------------------------------------------
    
    # -----------------Create the Bass part which is the forth track with long notes------------------------------
    # We can get the numerator and denominator in MIDI file and set the different rules.
    Bass_3rd = SolFa_to_Melody(Note_SolFaNameList3rd)
    Bass_note = get_Bass(file_path, Bass_3rd, 'note')
    Bass_time = get_Bass(file_path, Bass_3rd, 'time')
    Bass_velocity = get_Bass(file_path, Bass_3rd, 'velocity')
    print("3rd intervals notes:", Bass_3rd)
    print("Bass Note: ", Bass_note)
    print("Bass Velocity: ", Bass_velocity)
    print("Bass Time: ", Bass_time)
    print("Bass Note length: ", len(Bass_note))
    print("Max and min of Bass_note: ", max(Bass_note), " and ", min(Bass_note))

    # -----------------Create the Bass part which is the forth track with long notes------------------------------
    
    print("Max and min of original note list: ", max(note_list[0]), " and ", min(note_list[0]))

    # --------------------------------Create a new Midi File------------------------------------------------------

    Tracks = [len(instrument_List[1]), len(instrument_List[2]), len(instrument_List[3]), len(instrument_List[4])]

    part1, part2, part3, part4 = [], [], [], []
    for i in range(Tracks[0]):
        part1.append(MidiTrack())
    for i in range(Tracks[1]):
        part2.append(MidiTrack())
    for i in range(Tracks[2]):
        part3.append(MidiTrack())
    for i in range(Tracks[3]):
        part4.append(MidiTrack())

    New_mid = MidiFile()
    # Melody part
    print("Melody Part")
    ins_num = get_Instrument_info('num')
    print(ins_num)
    print(ins_num)
    print(instrument_List)
    for i in range(len(part1)):
        New_mid.tracks.append(part1[i])
        part1[i].append(Message('program_change', channel=0, program=ins_num[instrument_List[1][i]-1], time=0))
        part1[i].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
        if ins_num[instrument_List[1][i]-1] == 10:
            for k in range(len(note_list[0])):
                note_list[0][k] += 24
        for j in range(len(channel_list[0])):
            part1[i].append(
                Message('note_on', note=note_list[0][j], velocity=velocity_list[0][j], time=time_list[0][j]))
        print("Melody_ins")
        print(ins_num[instrument_List[1][i]-1])
    # Counter Melody part
    for i in range(len(part2)):
        New_mid.tracks.append(part2[i])
        part2[i].append(Message('program_change', channel=0, program=ins_num[instrument_List[2][i]-1], time=0))
        part2[i].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
        print("part2")
        if ins_num[instrument_List[2][i]-1] == 10:
            for k in range(len(CounterMelody_List)):
                CounterMelody_List[k] += 24
        try:
            for j in range(len(CounterMelody_List)):
                part2[i].append(
                    Message('note_on', note=CounterMelody_List[j], velocity=velocity_list[0][j], time=time_list[0][j]))
        except BaseException as e:
            print(e)
        else:
            print("C_Melody_ins")
            print(ins_num[instrument_List[2][i] - 1])

    # Rhythm part
    for i in range(len(part3)):
        New_mid.tracks.append(part3[i])
        part3[i].append(Message('program_change', channel=0, program=ins_num[instrument_List[3][i]-1], time=0))
        part3[i].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
        if ins_num[instrument_List[3][i]-1] == 10:
            for k in range(len(Rhythm_note)):
                Rhythm_note[k] += 48
        elif ins_num[instrument_List[3][i]-1] == 117 or ins_num[instrument_List[3][i]-1] == 107:
            for k in range(len(Rhythm_note)):
                Rhythm_note[k] += 12

        for j in range(len(Rhythm_note)):
            if j % 2 == 0:
                part3[i].append(
                    Message('note_on', note=Rhythm_note[j] + 12, velocity=Rhythm_velocity[j] - 20,
                            time=Rhythm_time[j]))
            else:
                part3[i].append(
                    Message('note_on', note=Rhythm_note[j] + 12, velocity=Rhythm_velocity[j], time=Rhythm_time[j]))

        print("Rhythm_ins")
        print(ins_num[instrument_List[3][i]-1])
    # Base part
    for i in range(len(part4)):
        New_mid.tracks.append(part4[i])
        part4[i].append(Message('program_change', channel=0, program=ins_num[instrument_List[4][i]-1], time=0))
        part4[i].append(MetaMessage('set_tempo', tempo=Tempo, time=0))
        if ins_num[instrument_List[4][i]-1] == 10:
            for k in range(len(Bass_note)):
                Bass_note[k] += 60
        elif ins_num[instrument_List[4][i]-1] == 117:
            for k in range(len(Bass_note)):
                Bass_note[k] += 24

        for j in range(len(Bass_note)):
            if j % 2 == 0:
                part4[i].append(
                    Message('note_on', note=Bass_note[j], velocity=Bass_velocity[j] - 10, time=Bass_time[j]))
            else:
                part4[i].append(
                    Message('note_on', note=Bass_note[j], velocity=Bass_velocity[j], time=Bass_time[j]))

        print("Bass_ins")
        print(ins_num[instrument_List[4][i]-1])
    Filename = "MuseLab_Song.mid"
    Filename = check_filename_available(Filename)
    New_mid.save('./music/Output/' + Filename)
    File_Position = './music/Output/' + Filename
    Input_Position = './music/Output/' + Input_File_name
    MuseScore = check_Sys_and_Open_File(File_Position, Input_Position)
    # New3rd = converter.parse('./music/Output/' + Filename)
    # New3rd.write("xml", "./music/Output/MuseLab_Song.xml")
    # --------------------------------Create a new Midi File------------------------------------------------------
    return MuseScore
    # Open the output through MuseScore in different system
