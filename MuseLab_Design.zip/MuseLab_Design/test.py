#
# ins_num_list = []
# ins_name_list = []
# file_list = open("instruments.txt", "r")
#
# for line in file_list.readlines():
#     for i in range(len(line)):
#         if line[i] == ',':
#             if line[i+2] == '\n':
#                 ins_num_list.append(int(line[i + 1]))
#             elif line[i+3] == "\n":
#                 ins_num_list.append((int(line[i + 1])) * 10 + (int(line[i + 2])))
#             else:
#                 ins_num_list.append((int(line[i + 1])) * 100 + (int(line[i + 2])) * 10 + (int(line[i + 3])))
#         elif line[i] == '*':
#             try:
#                 name = ''
#                 j = i
#                 k = 0
#                 while j > 0:
#                     name = name + line[k]
#                     j -= 1
#                     k += 1
#                 ins_name_list.append(name)
#             except BaseException as e:
#                 print(e)
#
# print(ins_num_list)
# print(ins_name_list)
#
# ins_num_list = []
# ins_name_list = []
# file_list = open("Muse_Type.txt", "r")
# num = 0
# for line in file_list.readlines():
#     for i in range(len(line)):
#         if line[i] == '*':
#             name = ''
#             j = i
#             k = 0
#             while j > 0:
#                 name = name + line[k]
#                 j -= 1
#                 k += 1
#             ins_name_list.append(name)
#
# print(ins_num_list)
# print(ins_name_list)
from Functions import *

def get_Rhythm(file_path, RhythmType, Type):
    """

    :param file_path:
    :param RhythmType:
    :param Type:
    :return:
    """
    Note_SolFaNameList3rd = get_3rd_intervals(file_path)
    Bass_3rd = SolFa_to_Melody(Note_SolFaNameList3rd)
    Bass_note = get_Bass(file_path, Bass_3rd, 'note')
    Bass_time = get_Bass(file_path, Bass_3rd, 'time')
    Rhythm_note, Rhythm_time, Rhythm_velocity = [], [], []
    Rhythm_note1, Rhythm_note2, Rhythm_note3 = [], [], []
    Rhythm_time1, Rhythm_time2, Rhythm_time3 = [], [], []
    Rhythm_velocity1, Rhythm_velocity2, Rhythm_velocity3 = [], [], []
    time_list = get_midi_info(file_path, 'time')
    bar_n = 1
    time_n = 0
    if RhythmType == 1:
        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(4):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(25)
                    elif j % 2 == 1:
                        Rhythm_time.append(455)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(25)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    # # if Rhythm half note ----
    if RhythmType == 2:

        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(2):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(49)
                    elif j % 2 == 1:
                        Rhythm_time.append(911)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(49)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    # # if Rhythm quaver/eighth note
    if RhythmType == 3:

        n = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(8):
                    if i == 0 and j == 0 and n == 1:
                        Rhythm_time.append(0)
                        Rhythm_velocity.append(80)
                    if j % 2 == 0 and n == 0:
                        Rhythm_velocity.append(80)
                        Rhythm_time.append(13)
                    elif j % 2 == 1:
                        Rhythm_time.append(227)
                        Rhythm_velocity.append(0)
                    n = 0
                    Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(13)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    # # if Rhythm doted half note
    if RhythmType == 4:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(4):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(683)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(4):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(37)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(25)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 5:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(42)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(678)
                        Rhythm_note.append(Bass_note[i])

            else:
                if i % 2 == 0:
                    Rhythm_time.append(42)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 6:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(7):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(7):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i])

            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 7:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(7):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(7):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(13)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 8:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(5):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(37)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(455)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(25)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(5):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(227)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(13)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(683)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(37)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 9:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(8):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(8):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(32)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 10:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(11):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 9:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 10:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(11):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(00)
                            Rhythm_time.append(448)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 9:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 10:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)

                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 11:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(9):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(9):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 12:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(678)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(42)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i])

            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 13:

        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(9):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 6:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 7:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 8:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(9):
                        if j == 0:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 1:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 2:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 3:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 4:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 5:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 6:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        elif j == 7:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(2)
                        elif j == 8:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(118)
                        Rhythm_note.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time.append(2)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 14:
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(0)
                        elif j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(338)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(22)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 1:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(448)
                        elif j == 2:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(32)
                        elif j == 3:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        elif j == 4:
                            Rhythm_velocity.append(80)
                            Rhythm_time.append(12)
                        elif j == 5:
                            Rhythm_velocity.append(0)
                            Rhythm_time.append(228)
                        Rhythm_note.append(Bass_note[i])

            else:
                if i % 2 == 0:
                    Rhythm_time.append(12)
                    Rhythm_velocity.append(80)
                else:
                    Rhythm_velocity.append(0)
                    Rhythm_time.append(Bass_time[i])
                Rhythm_note.append(Bass_note[i])

    if RhythmType == 15:
        # Type 2
        n1 = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(2):
                    if i == 0 and j == 0 and n1 == 1:
                        Rhythm_time1.append(0)
                        Rhythm_velocity1.append(80)
                    if j % 2 == 0 and n1 == 0:
                        Rhythm_velocity1.append(80)
                        Rhythm_time1.append(49)
                    elif j % 2 == 1:
                        Rhythm_time1.append(911)
                        Rhythm_velocity1.append(0)
                    n1 = 0
                    Rhythm_note1.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time1.append(49)
                    Rhythm_velocity1.append(80)
                else:
                    Rhythm_velocity1.append(0)
                    Rhythm_time1.append(Bass_time[i])
                Rhythm_note1.append(Bass_note[i])

        # Type 1
        n2 = 1
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                for j in range(4):
                    if i == 0 and j == 0 and n2 == 1:
                        Rhythm_time2.append(0)
                        Rhythm_velocity2.append(80)
                    if j % 2 == 0 and n2 == 0:
                        Rhythm_velocity2.append(80)
                        Rhythm_time2.append(25)
                    elif j % 2 == 1:
                        Rhythm_time2.append(455)
                        Rhythm_velocity2.append(0)
                    n2 = 0
                    Rhythm_note2.append(Bass_note[i])
            else:
                if i % 2 == 0:
                    Rhythm_time2.append(25)
                    Rhythm_velocity2.append(80)
                else:
                    Rhythm_velocity2.append(0)
                    Rhythm_time2.append(Bass_time[i])
                Rhythm_note2.append(Bass_note[i])

        # Type 14
        for i in range(len(Bass_note)):
            if i < len(Bass_note) - 2:
                if i % 2 == 0:
                    for j in range(6):
                        if i == 0 and j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(0)
                        elif j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 1:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(338)
                        elif j == 2:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(22)
                        elif j == 3:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(338)
                        elif j == 4:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(22)
                        elif j == 5:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        Rhythm_note3.append(Bass_note[i])
                elif i % 2 == 1:
                    for j in range(6):
                        if j == 0:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 1:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(448)
                        elif j == 2:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(32)
                        elif j == 3:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        elif j == 4:
                            Rhythm_velocity3.append(80)
                            Rhythm_time3.append(12)
                        elif j == 5:
                            Rhythm_velocity3.append(0)
                            Rhythm_time3.append(228)
                        Rhythm_note3.append(Bass_note[i])

            else:
                if i % 2 == 0:
                    Rhythm_time3.append(12)
                    Rhythm_velocity3.append(80)
                else:
                    Rhythm_velocity3.append(0)
                    Rhythm_time3.append(Bass_time[i])
                Rhythm_note3.append(Bass_note[i])

        bar_num = Bar_Count(time_list)
        print("1t:",Rhythm_time1)
        print("2t:",Rhythm_time2)
        print("3t:",Rhythm_time3)
        print("1n:",Rhythm_note1)
        print("2n:",Rhythm_note2)
        print("3n:",Rhythm_note3)
        z = 0
        print(bar_num)
        print(Rhythm_time)
        i = 1
        while i < bar_num:
            if i < 3:
                for j in range(len(Rhythm_time1)):
                    time_n += Rhythm_time1[j]
                    print("time:", time_n)
                    if time_n > 1920:
                        bar_n += 1
                        print("bar_n:", bar_n)
                        time_n -= 1920
                        if bar_n == 4:
                            i += 3
                            Rhythm_note.pop()
                            Rhythm_velocity.pop()
                            print("1:", Rhythm_note)
                            print("1:", Rhythm_time)
                            print("1:", Rhythm_velocity)
                            bar_n = 1
                            break
                    if bar_n < 4:
                        Rhythm_note.append(Rhythm_note1[j])
                        Rhythm_velocity.append(Rhythm_velocity1[j])
                        Rhythm_time.append(Rhythm_time1[j])

            elif i == 4:
                for j in range(len(Rhythm_note2)):
                    time_n += Rhythm_time2[j]
                    if bar_n == 4:
                        Rhythm_time.append(Rhythm_time2[j+1])
                    if time_n > 1920:
                        bar_n += 1
                        time_n -= 1920
                    if bar_n == 4:
                        Rhythm_note.append(Rhythm_note2[j-1])
                        Rhythm_velocity.append(Rhythm_velocity2[j-1])
                    elif bar_n > 4:
                        print("2:", Rhythm_note)
                        print("2:", Rhythm_time)
                        print("2:", Rhythm_velocity)
                        time_n = 0
                        bar_n = 1
                        i += 1
                        break
            else:
                for j in range(len(Rhythm_time3)):
                    time_n += Rhythm_time3[j]
                    if bar_n > 4 and j < len(Rhythm_note3):
                        Rhythm_time.append(Rhythm_time3[j-1])
                        z = j
                    if time_n > 1920:
                        bar_n += 1
                        i += 1
                        time_n -= 1920
                    if bar_n > 4:
                        Rhythm_note.append(Rhythm_note3[j-1])
                        Rhythm_velocity.append(Rhythm_velocity3[j-1])

                Rhythm_time.append(Rhythm_time3[z])
                Rhythm_note.append(Rhythm_note3[z])
                Rhythm_velocity.append(Rhythm_velocity3[z])
                print("3:", Rhythm_note)
                print("3:", Rhythm_time)
                print("3:", Rhythm_velocity)
                print(i)
                break

    if Type == 'note':
        return Rhythm_note
    elif Type == 'time':
        return Rhythm_time
    elif Type == 'velocity':
        return Rhythm_velocity

if __name__ == '__main__':
    file = './music/Test_Music/Monkey_Dance1.mid'
    R = 15
    n_list = get_Rhythm(file, R, 'note')
    t_list = get_Rhythm(file, R, 'time')
    v_list = get_Rhythm(file, R, 'velocity')
    print(n_list)
    print(t_list)
    print(len(n_list))
    print(len(t_list))
    print(len(v_list))

