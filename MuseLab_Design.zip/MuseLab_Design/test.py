
ins_num_list = []
ins_name_list = []
file_list = open("instruments.txt", "r")

for line in file_list.readlines():
    for i in range(len(line)):
        if line[i] == ',':
            if line[i+2] == '\n':
                ins_num_list.append(int(line[i + 1]))
            elif line[i+3] == "\n":
                ins_num_list.append((int(line[i + 1])) * 10 + (int(line[i + 2])))
            else:
                ins_num_list.append((int(line[i + 1])) * 100 + (int(line[i + 2])) * 10 + (int(line[i + 3])))
        elif line[i] == '*':
            try:
                name = ''
                j = i
                k = 0
                while j > 0:
                    name = name + line[k]
                    j -= 1
                    k += 1
                ins_name_list.append(name)
            except BaseException as e:
                print(e)

print(ins_num_list)
print(ins_name_list)

ins_num_list = []
ins_name_list = []
file_list = open("Muse_Type.txt", "r")
num = 0
for line in file_list.readlines():
    for i in range(len(line)):
        if line[i] == '*':
            name = ''
            j = i
            k = 0
            while j > 0:
                name = name + line[k]
                j -= 1
                k += 1
            ins_name_list.append(name)

print(ins_num_list)
print(ins_name_list)