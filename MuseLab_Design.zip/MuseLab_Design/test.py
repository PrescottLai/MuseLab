from Functions import *

if __name__ == '__main__':

    # file_path = 'music/Output/MuseLab_Song.mid'
    # mid = MidiFile(file_path)
    # Tempo = get_tempo(file_path)
    # note_list = get_midi_info(file_path, 'note')
    # velocity_list = get_midi_info(file_path, 'velocity')
    # time_list = get_midi_info(file_path, 'time')
    # for i in range(len(note_list)):
    #     print(note_list[i])
    #     print("len:", len(note_list[i]))
    # print("note_length:", len(note_list))
    # print("note_list:", note_list)
    # print("time_length:", len(time_list))
    # print("time:", time_list)
    # print("velocity_length:", len(velocity_list))
    # print("velocity_list:", velocity_list)
    # print("Input_mid_Info: ", mid)
    # print("MIDI data: ", mid)
    # print("Melody_Tempo:", Tempo)
    #
    # mid = MidiFile(file_path)
    # list_c, list_n, list_v, list_t, channel_list, note_list, velocity_list, time_list = \
    #     [], [], [], [], [], [], [], []
    # # -----------Grab the useful message from original midi file, Note number, Key, Key signature, Tempo --------
    # for i in range(len(mid.tracks)):
    #     print(mid.tracks[i])
    #     for msg in mid.tracks[i]:
    #         if msg.type == 'note_on' or msg.type == 'note_off':
    #             list_c.append(msg.channel)
    #             list_n.append(msg.note)
    #             list_v.append(msg.velocity)
    #             list_t.append(msg.time)
    #     print(list_n)
    #     note_list.append(list_n)
    #     channel_list.append(list_c)
    #     velocity_list.append(list_v)
    #     time_list.append(list_t)
    #     list_n, list_t, list_c, list_v = [], [], [], []
    #     print(note_list)
    #     print("after append:", len(note_list[i]))
    instrument_list = [[], [15], [15], [15], [67], [67], 120]
    print(type(instrument_list[-1]))
    if type(instrument_list[-1]) == 'int':
        print("yes")
    print(instrument_list[-1])
    file_path = "./music/Output/MuseLab_Song_57.mid"
    mid = MidiFile(file_path)
    print(mid)
    index = 1
    for msg in mid:
        if msg.type == 'program_change':
            print(1)
            print("before:", msg.program)
            msg.program = int(instrument_list[index][0])
            print("after:", msg.program)
            index += 1
    list_c, list_n, list_v, list_t, channel_list, note_list, velocity_list, time_list = \
        [], [], [], [], [], [], [], []
    # -----------Grab the useful message from original midi file, Note number, Key, Key signature, Tempo --------
    for i in range(len(mid.tracks)):
        for msg in mid.tracks[i]:
            if msg.type == 'note_on' or msg.type == 'note_off':
                list_n.append(msg.note)
                list_v.append(msg.velocity)
                list_t.append(msg.time)
                list_c.append(msg.channel)
        note_list.append(list_n)
        velocity_list.append(list_v)
        time_list.append(list_t)
        channel_list.append(list_c)
    print(len(note_list))
    print(note_list)
    print(len(time_list))
    print(time_list)
    print(len(velocity_list))
    print(velocity_list)
    print(len(channel_list))
    print(channel_list)